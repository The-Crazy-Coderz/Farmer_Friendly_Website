const nodemailer = require("nodemailer");
console.log("DEBUG >> nodemailer.createTransport:", typeof nodemailer.createTransport);
let otpStore = {}; // email → otp (valid for 5 min)

function generateOTP() {
    return Math.floor(100000 + Math.random() * 900000).toString();
}

// ✅ Send OTP to email
async function sendOtpToEmail(email) {
    const otp = generateOTP();
    otpStore[email] = otp;

    setTimeout(() => delete otpStore[email], 5 * 60 * 1000); // auto-expire after 5 min

    // 🔍 DEBUG log environment variables
    console.log("🔐 Sending from:", process.env.OTP_GMAIL);
    console.log("🔑 Using password:", process.env.OTP_GMAIL_PASSWORD ? '✓ (loaded)' : '❌ (missing)');
    console.log("📧 Sending OTP to:", email);
    console.log("🧾 OTP Generated:", otp);

    // ✅ Validate env variables
    if (!process.env.OTP_GMAIL || !process.env.OTP_GMAIL_PASSWORD) {
        return {
            success: false,
            error: "Missing Gmail or password in .env file",
        };
    }

    const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
            user: process.env.OTP_GMAIL,
            pass: process.env.OTP_GMAIL_PASSWORD,
        },
    });

    const mailOptions = {
        from: `"Farmer Platform" <${process.env.OTP_GMAIL}>`,
        to: email,
        subject: "OTP for Registration",
        text: `Your OTP is: ${otp}. It will expire in 5 minutes.`,
    };

    try {
        await transporter.sendMail(mailOptions);
        console.log("✅ OTP Email Sent!");
        return { success: true };
    } catch (error) {
        console.error("❌ Error sending OTP:", error);
        return { success: false, error: error.message };
    }
}

// ✅ Verify OTP with expiry check
function verifyOtp(email, enteredOtp) {
    const otp = otpStore[email];
    
    // Check if OTP exists and is not expired
    if (otp && otp === enteredOtp) {
        return true;
    }
    return false;
}

module.exports = { sendOtpToEmail, verifyOtp };

