const nodemailer = require('nodemailer');
require('dotenv').config();

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.OTP_GMAIL,
    pass: process.env.OTP_GMAIL_PASSWORD
  }
});

const sendOTP = async (email, otp) => {
  const mailOptions = {
    from: process.env.OTP_GMAIL,
    to: email,
    subject: 'Your OTP for Verification',
    text: `Your OTP is ${otp}. It will expire in 5 minutes.`
  };

  await transporter.sendMail(mailOptions);
};

module.exports = sendOTP;
