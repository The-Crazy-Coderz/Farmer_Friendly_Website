// utils/otpStore.js

// Simple in-memory store for OTPs
const otpStore = {};

module.exports = otpStore;
