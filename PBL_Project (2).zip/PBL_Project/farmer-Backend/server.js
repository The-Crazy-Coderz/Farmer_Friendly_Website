/*const express = require("express");
const mysql = require("mysql2");

const app = express();
const PORT = 5000;

// Create MySQL connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "p@sSw0rD",  // Your MySQL password
    database: "farmer_db",
});

// Connect to MySQL
db.connect((err) => {
    if (err) {
        console.error("Database connection failed: " + err.message);
        return;
    }
    console.log("Connected to MySQL database");
});

// API to fetch all farmers
app.get("/farmers", (req, res) => {
    db.query("SELECT * FROM farmers", (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        res.json(results);
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});*/


/*
const express = require("express");
const db = require("./db");  // MySQL Connection
require("./mongodb");  // MongoDB Connection

const app = express();
const PORT = process.env.PORT || 5000;

app.get("/farmers", (req, res) => {
    db.query("SELECT * FROM farmers", (err, results) => {
        if (err) {
            res.status(500).send(err);
            return;
        }
        res.json(results);
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});*/

/*

const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config();
const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// Database Connection
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log("MongoDB Connection Error:", err));

// mongoose.connect(process.env.MONGO_URI, {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// }).then(() => console.log("MongoDB Connected"))
//   .catch((err) => console.log("MongoDB Connection Error:", err));

// Import Routes
const farmerRoutes = require("../routes/farmerroutes");
const consumerRoutes = require("../routes/consumerroute");
const industryRoutes = require("../routes/industry");

// Use Routes
app.use("/api", farmerRoutes);
app.use("/api", consumerRoutes);
app.use("/api", industryRoutes);

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));





require('dotenv').config();
const mongoose = require('mongoose');

// Connect to Farmers DB
const farmersDb = mongoose.createConnection(process.env.MONGO_FARMERS, { useNewUrlParser: true, useUnifiedTopology: true });
farmersDb.on("connected", () => console.log("Connected to Farmers DB"));

// Connect to Crops DB
const cropsDb = mongoose.createConnection(process.env.MONGO_CROPS, { useNewUrlParser: true, useUnifiedTopology: true });
cropsDb.on("connected", () => console.log("Connected to Crops DB"));

// Connect to Fertilizers DB
const fertilizersDb = mongoose.createConnection(process.env.MONGO_FERTILIZERS, { useNewUrlParser: true, useUnifiedTopology: true });
fertilizersDb.on("connected", () => console.log("Connected to Fertilizers DB"));

// Connect to Transactions DB
const transactionsDb = mongoose.createConnection(process.env.MONGO_TRANSACTIONS, { useNewUrlParser: true, useUnifiedTopology: true });
transactionsDb.on("connected", () => console.log("Connected to Transactions DB"));

// Handle connection errors
farmersDb.on("error", err => console.log("Farmers DB Connection Error:", err));
cropsDb.on("error", err => console.log("Crops DB Connection Error:", err));
fertilizersDb.on("error", err => console.log("Fertilizers DB Connection Error:", err));
transactionsDb.on("error", err => console.log("Transactions DB Connection Error:", err));

*/

/*
const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");

dotenv.config(); // Load environment variables

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// MongoDB Connections
const farmersDb = mongoose.createConnection(process.env.MONGO_FARMERS);
farmersDb.on("connected", () => console.log("Connected to Farmers DB"));

const cropsDb = mongoose.createConnection(process.env.MONGO_CROPS);
cropsDb.on("connected", () => console.log("Connected to Crops DB"));

const fertilizersDb = mongoose.createConnection(process.env.MONGO_FERTILIZERS);
fertilizersDb.on("connected", () => console.log("Connected to Fertilizers DB"));

const transactionsDb = mongoose.createConnection(process.env.MONGO_TRANSACTIONS);
transactionsDb.on("connected", () => console.log("Connected to Transactions DB"));

// Handle connection errors
farmersDb.on("error", err => console.log("Farmers DB Connection Error:", err));
cropsDb.on("error", err => console.log("Crops DB Connection Error:", err));
fertilizersDb.on("error", err => console.log("Fertilizers DB Connection Error:", err));
transactionsDb.on("error", err => console.log("Transactions DB Connection Error:", err));

// Import Routes
const farmerRoutes = require("../routes/farmerroutes");  // Check if the file name is correct
const consumerRoutes = require("../routes/consumerroute");
const industryRoutes = require("../routes/industry");

// Use Routes
app.use("/api", farmerRoutes);
app.use("/api", consumerRoutes);
app.use("/api", industryRoutes);

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));

*/
/*
const express = require("express");
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
//const connectDB = require("./config/db"); // Import centralized MongoDB connection function

dotenv.config(); // Load environment variables

const app = express();

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());
app.use(cors());

// MongoDB Connections (Multiple Databases)
const {
    farmersDb,
    consumersDb,
    cropsDb,
    fertilizersDb,
    transactionsDb,
  } = require("./config/dbConnections");
// User Schema for Authentication
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String
});
const User = farmersDb.model("User", userSchema); // Save users in farmersDB

// 🔹 Register Route
app.post("/api/register", async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        // Hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering user", error });
    }
});

// 🔹 Login Route
app.post("/api/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        // Compare passwords
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        // Generate JWT Token
        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

        res.json({ message: "Login successful", token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error });
    }
});

// Import Routes
const farmerRoutes = require("../routes/farmerroutes");
const consumerRoutes = require("../routes/consumerroute.js");
const industryRoutes = require("../routes/industry");

// Use Routes
app.use("/api/farmer", farmerRoutes);
app.use("/api/consumer", consumerRoutes);
app.use("/api/industry", industryRoutes);

// Default Route
app.get("/", (req, res) => {
    res.send("✅ API is running...");
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
*/
/*
const express = require("express");
const mongoose = require("mongoose");
//const dotenv = require("dotenv");
require("dotenv").config({ path: __dirname + "/.env" });
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const bodyParser = require("body-parser");
const path = require("path");
const cropRoutes = require('../routes/cropsroute');


//dotenv.config(); // Load environment variables

const app = express();
app.use('/api/crops', cropRoutes);

// MongoDB Connections (Multiple Databases)
const { farmersDb, consumersDb, cropsDb, fertilizersDb, transactionsDb } = require(path.join(__dirname, '..', 'models', 'dbConnections'));

// Middleware
app.use(express.json());
app.use(cors());

// User Schema for Authentication
const userSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String
});
const User = farmersDb.model("User", userSchema); // Save users in farmersDB

// 🔹 Register Route
app.post("/api/register", async (req, res) => {
    try {
        const { username, email, password } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "User already exists" });
        }

        // Hash password before saving
        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        res.status(201).json({ message: "User registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering user", error });
    }
});

// 🔹 Login Route
app.post("/api/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        // Compare passwords
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        // Generate JWT Token
        const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });

        res.json({ message: "Login successful", token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error });
    }
});

// Import Routes
const farmerRoutes = require(path.join(__dirname, '..', 'routes', 'farmerroutes'));
const consumerRoutes = require(path.join(__dirname, '..', 'routes', 'consumerroute.js'));
const industryRoutes = require(path.join(__dirname, '..', 'routes', 'industry'));

// Use Routes
app.use("/api/farmer", farmerRoutes);
app.use("/api/consumer", consumerRoutes);
app.use("/api/industry", industryRoutes);

// Default Route
app.get("/", (req, res) => {
    res.send("✅ API is running...");
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

*/

/*     with industry
require("dotenv").config(); // ✅ Loads .env
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const path = require("path");

require("dotenv").config({ path: __dirname + "/.env" });

const app = express();

// 🔹 Middlewares
app.use(express.json());
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// 🔹 MongoDB Multi-DB Connections
const {
  farmersDb,
  consumersDb,
  cropsDb,
  fertilizersDb,
  transactionsDb
} = require(path.join(__dirname, "..", "models", "dbConnections"));

// 🔹 Import Routes
const cropRoutes = require("../routes/cropsroute");
const farmerRoutes = require("../routes/farmerroutes");
const consumerRoutes = require("../routes/consumerroute");
const industryRoutes = require("../routes/industry");

// 🔹 API Routes
app.use("/api/crops", cropRoutes);
app.use("/api/farmer", farmerRoutes); // Keep this route path as it is
app.use("/api/consumer", consumerRoutes);
app.use("/api/industry", industryRoutes);

// 🔹 Default Route
app.get("/", (req, res) => {
  res.send("✅ API is running...");
});

// 🔹 Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));

*/
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const mongoose = require("mongoose");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("✅ MongoDB connected"))
  .catch((err) => console.error("❌ Connection error:", err));

// Routes
const farmerRoutes = require("../routes/farmerroutes"); // Correct path here
const consumerRoutes = require("../routes/consumerroute");

app.use("/api/farmer", farmerRoutes);
app.use("/api/consumer", consumerRoutes);

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});
