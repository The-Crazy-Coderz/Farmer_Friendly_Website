require('dotenv').config();
const sendOTP = require('./utils/mailer');

sendOTP('your-email@example.com', '123456')
  .then(() => console.log("OTP sent successfully"))
  .catch((err) => console.error("Error sending OTP:", err));
