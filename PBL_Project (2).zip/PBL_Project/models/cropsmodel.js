const mongoose = require('mongoose');
const { cropsDb } = require('./dbConnections'); 


const cropSchema = new mongoose.Schema({
  farmerId: { type: String, required: true },
  cropType: { type: String, required: true },
  quantity: { type: Number, required: true },
  expectedPrice: { type: Number, required: true },
  address: { type: String, required: true },
  imageUrl: { type: String }, // will store cloud or local image path
  createdAt: { type: Date, default: Date.now }
});

module.exports = cropsDb.model('Crop', cropSchema);
