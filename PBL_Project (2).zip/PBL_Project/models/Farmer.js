/*const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const FarmerSchema = new mongoose.Schema({
  farmer_id: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
});

// Hash password before saving
FarmerSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

module.exports = mongoose.model("Farmer", FarmerSchema);
*/
/*
const mongoose = require('mongoose');
const {farmersDb}=require("./dbConnections");
const FarmerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  date: { type: Date, default: Date.now }
});

module.exports = farmersDb.model('Farmer', FarmerSchema);
*/
/*
const mongoose = require('mongoose');
const { farmersDb } = require("./dbConnections"); // Ensure the correct connection is used

const farmerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phoneNumber: { type: String, required: true },
  dob: { type: Date, required: true },
  gender: { type: String, required: true },
  address: { type: String, required: true },
  age: { type: Number, required: true },
  password: { type: String, required: true },
  farmLocation: { type: String }, // Farmer specific
  farmType: { type: String },
  farmSize: { type: Number },
  crops: { type: [String] }, // Array of crop names
});

const Farmer = mongoose.model('Farmer', farmerSchema);
module.exports = Farmer;

*/

const mongoose = require('mongoose');
const { farmersDb } = require("./dbConnections.js");

const farmerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: {
    type: String,
    required: true,
    validate: {
      validator: function(v) {
        return /^\d{10}$/.test(v); // 10-digit number validation
      },
      message: props => `${props.value} is not a valid 10-digit phone number!`
    }
  },
  dob: { type: Date, required: true },
  gender: { type: String, required: true },
  address: { type: String, required: true },
  password: { type: String, required: true },
  farmLocation: { type: String, required: true },
  farmType: { type: String, required: true },
  farmSize: { type: Number, required: true },
  crops: { type: String, required: true }, // crops as a single string input
});

const Farmer = farmersDb.model('Farmer', farmerSchema);
module.exports = Farmer;
