/*const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const ConsumerSchema = new mongoose.Schema({
  consumer_id: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
});

// Hash password before saving
ConsumerSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

module.exports = mongoose.model("Consumer", ConsumerSchema);
*/
/*
const mongoose = require('mongoose');
const {consumersDb} = require("./dbConnections");


const consumerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phoneNumber: { type: String, required: true },
  dob: { type: Date, required: true },
  gender: { type: String, required: true },
  address: { type: String, required: true },
  age: { type: Number, required: true },
  password: { type: String, required: true },
  preferredProducts: { type: [String] }, // Consumer specific
});

const Consumer = mongoose.model('Consumer', consumerSchema);
module.exports = Consumer;
*/

const mongoose = require('mongoose');
const { consumersDb } = require("./dbConnections");

const consumerSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: {
    type: String,
    required: true,
    validate: {
      validator: function(v) {
        return /^\d{10}$/.test(v);
      },
      message: props => `${props.value} is not a valid 10-digit phone number!`
    }
  },
  dob: { type: Date, required: true },
  gender: { type: String, required: true },
  address: { type: String, required: true },
  password: { type: String, required: true },
  preferredProducts: { type: String }, // optional single string input
});

const Consumer = consumersDb.model('Consumer', consumerSchema);
module.exports = Consumer;
