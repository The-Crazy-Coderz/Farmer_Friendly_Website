/*const mongoose = require("mongoose");
const dotenv=require('dotenv');
dotenv.config();
const consumerConnection = mongoose.createConnection("mongodb://localhost:27017/consumer_db", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
});

module.exports = consumerConnection;
//module.exports=consumerConnection;
console.log("✅ dbConsumer.js loaded from:", __dirname);
*/



/*    with industry
const mongoose = require("mongoose");
const farmersDb = mongoose.createConnection(process.env.MONGO_FARMERS);
const consumersDb=mongoose.createConnection(process.env.MONGO_CONSUMERS);
const industryDb=mongoose.createConnection(process.env.MONGO_INDUSTRY);
const cropsDb = mongoose.createConnection(process.env.MONGO_CROPS);
const fertilizersDb = mongoose.createConnection(process.env.MONGO_FERTILIZERS);
const transactionsDb = mongoose.createConnection(process.env.MONGO_TRANSACTIONS);

farmersDb.on("connected", () => console.log("✅ Connected to Farmers DB"));
consumersDb.on("connected",()=> console.log("✅ Connected to Consumers DB"));
industryDb.on("connected",()=> console.log("✅ Connected to Industry DB"));
cropsDb.on("connected", () => console.log("✅ Connected to Crops DB"));
fertilizersDb.on("connected", () => console.log("✅ Connected to Fertilizers DB"));
transactionsDb.on("connected", () => console.log("✅ Connected to Transactions DB"));

farmersDb.on("error", (err) => console.log("❌ Farmers DB Connection Error:", err));
consumersDb.on("error",(err)=>console.log("❌ Consumers DB Connection Error:", err));
industryDb.on("error",(err)=>console.log("❌ Industry DB Connection Error:", err));
cropsDb.on("error", (err) => console.log("❌ Crops DB Connection Error:", err));
fertilizersDb.on("error", (err) => console.log("❌ Fertilizers DB Connection Error:", err));
transactionsDb.on("error", (err) => console.log("❌ Transactions DB Connection Error:", err));


module.exports = {
    farmersDb,
    consumersDb,
    industryDb,
    cropsDb,
    fertilizersDb,
    transactionsDb,
  };
  */
 /*
  const mongoose = require("mongoose");
  const dotenv = require("dotenv");
  dotenv.config();
  
  mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
  })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB Error:", err));
  */


  const mongoose = require("mongoose");
require("dotenv").config();

const farmersDb = mongoose.createConnection(process.env.MONGO_FARMERS, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const consumersDb = mongoose.createConnection(process.env.MONGO_CONSUMERS, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

farmersDb.on("connected", () => {
  console.log("✅ Connected to Farmers DB");
});
consumersDb.on("connected", () => {
  console.log("✅ Connected to Consumers DB");
});

module.exports = { farmersDb, consumersDb };
