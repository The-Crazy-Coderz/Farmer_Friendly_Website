document.getElementById("industryForm").addEventListener("submit", async function (e) {
    e.preventDefault();
  
    const companyName = document.getElementById("companyName").value;
    const email = document.getElementById("email").value;
    const gst = document.getElementById("gst").value;
    const location = document.getElementById("location").value;
  
    const response = await fetch("http://localhost:5000/api/industry/update-profile", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ companyName, email, gst, location })
    });
  
    const data = await response.json();
    if (data.success) {
      alert("Profile updated successfully!");
      location.reload();
    } else {
      alert("Update failed: " + data.msg);
    }
  });
  
  // Fetch transactions
  (async function loadTransactions() {
    const res = await fetch("http://localhost:5000/api/industry/transactions", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token")
      }
    });
    const result = await res.json();
    const list = document.getElementById("supplyHistory");
    list.innerHTML = result.transactions.map(t => `<li>${t.item} - ₹${t.amount}</li>`).join('');
  })();
  