// home.js

// Animate page fade-in
window.addEventListener('DOMContentLoaded', () => {
    document.body.style.opacity = 0;
    document.body.style.transition = "opacity 1s ease-in-out";
    setTimeout(() => {
      document.body.style.opacity = 1;
    }, 100);
  });
  
  // 3D Hover Effect on CTA Button
  const btn = document.querySelector(".btn");
  if (btn) {
    btn.addEventListener("mousemove", (e) => {
      const rect = btn.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      btn.style.transform = `rotateX(${y / -20}deg) rotateY(${x / 20}deg) scale(1.05)`;
    });
  
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "rotateX(0) rotateY(0) scale(1)";
    });
  
    btn.addEventListener("mousedown", () => {
      btn.style.transform += " scale(0.95)";
    });
  
    btn.addEventListener("mouseup", () => {
      btn.style.transform = btn.style.transform.replace(" scale(0.95)", "");
    });
  }
  