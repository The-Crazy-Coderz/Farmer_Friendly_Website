document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('searchOrder');
    const tableRows = document.querySelectorAll('#ordersTable tbody tr');
  
    searchInput.addEventListener('keyup', function () {
      const query = this.value.toLowerCase();
      tableRows.forEach(row => {
        const product = row.children[1].textContent.toLowerCase();
        row.style.display = product.includes(query) ? '' : 'none';
      });
    });
  
    // Load orders from localStorage if needed
  });
  
  // Simulate order data (can later be replaced with Firebase or API fetch)
  const orders = {
    '001': { product: 'Tomatoes', date: '2025-04-10', status: 'Delivered' },
    '002': { product: 'Potatoes', date: '2025-04-12', status: 'Pending' }
  };
  
  let currentOrderId = null;
  
  function viewOrder(orderId) {
    currentOrderId = orderId;
    const order = orders[orderId];
    document.getElementById('orderInfo').innerHTML = `
      <strong>Order ID:</strong> ${orderId}<br>
      <strong>Product:</strong> ${order.product}<br>
      <strong>Date:</strong> ${order.date}<br>
      <strong>Status:</strong> ${order.status}
    `;
    document.getElementById('orderModal').style.display = 'block';
  }
  
  function closeModal() {
    document.getElementById('orderModal').style.display = 'none';
  }
  
  function cancelOrder() {
    if (currentOrderId && orders[currentOrderId]) {
      orders[currentOrderId].status = 'Cancelled';
      alert(`Order ${currentOrderId} has been cancelled.`);
      closeModal();
      location.reload(); // reload to reflect status
    }
  }
  