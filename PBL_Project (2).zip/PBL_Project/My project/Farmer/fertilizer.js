const products = [
    { name: "Organic Booster", offer: "20% OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657920.png" },
    { name: "GrowFast+ B", offer: "Buy 1 Get 1", img: "https://cdn-icons-png.flaticon.com/512/7657/7657918.png" },
    { name: "PowerNPK 50", offer: "Flat ₹50 OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657925.png" },
    { name: "SoilPro Green", offer: "10% Cashback", img: "https://cdn-icons-png.flaticon.com/512/7657/7657923.png" },
    { name: "MagicRoot Boost", offer: "Free Delivery", img: "https://cdn-icons-png.flaticon.com/512/7657/7657930.png" },
    { name: "NitroGrow XL", offer: "Combo Offer", img: "https://cdn-icons-png.flaticon.com/512/7657/7657933.png" },
    { name: "K-Micro Plus", offer: "New Arrival", img: "https://cdn-icons-png.flaticon.com/512/7657/7657922.png" },
    { name: "BioBloom Advance", offer: "25% OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657932.png" },
    { name: "AgroZyme Spray", offer: "₹100 OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657931.png" },
    { name: "GreenEdge Pro", offer: "5% Discount", img: "https://cdn-icons-png.flaticon.com/512/7657/7657924.png" }
  ];
  
  let cart = [];
  let wishlist = [];
  let orders = [];
  
  function showSection(id) {
    document.querySelectorAll('section').forEach(sec => sec.classList.remove('visible'));
    document.getElementById(id).classList.add('visible');
  }
  
  function createCard(product) {
    return `
      <div class="product-card">
        <img src="${product.img}" alt="${product.name}">
        <h3>${product.name}</h3>
        <p>${product.offer}</p>
        <button onclick='addToCart(${JSON.stringify(product)})'>Add to Cart</button>
        <button onclick='addToWishlist(${JSON.stringify(product)})'>Add to Wishlist</button>
        <button onclick='buyNow(${JSON.stringify(product)})'>Buy Now</button>
      </div>
    `;
  }
  
  function renderList(containerId, items) {
    const container = document.getElementById(containerId);
    container.innerHTML = items.map(createCard).join('');
  }
  
  function addToCart(product) {
    if (cart.length >= 25) return alert("Cart is full (25 items max)");
    cart.push(product);
    renderList('cart-items', cart);
  }
  
  function addToWishlist(product) {
    wishlist.push(product);
    renderList('wishlist-items', wishlist);
  }
  
  function buyNow(product) {
    orders.push(product);
    renderList('order-items', orders);
    alert("Order placed successfully!");
  }
  
  function initProducts() {
    const productContainer = document.getElementById('product-list');
    productContainer.innerHTML = products.map(createCard).join('');
  }
  
  initProducts();
  