// crops.js

document.getElementById("uploadBtn").addEventListener("click", () => {
    Swal.fire({
      title: "Allow Access?",
      text: "We need permission to access your gallery.",
      icon: "question",
      showCancelButton: true,
      confirmButtonText: "Allow",
    }).then((result) => {
      if (result.isConfirmed) {
        // Simulated image selection
        Swal.fire({
          title: "Upload Crop Image",
          html: `
            <input type="file" id="cropImage" accept="image/*"><br/><br/>
            <input type="text" id="type" placeholder="Crop Type" class="swal2-input">
            <input type="number" id="quantity" placeholder="Quantity (kg)" class="swal2-input">
            <input type="number" id="price" placeholder="Expected Price (₹)" class="swal2-input">
            <input type="text" id="address" placeholder="Address" class="swal2-input">
          `,
          confirmButtonText: "Upload",
          preConfirm: () => {
            const type = document.getElementById("type").value;
            const quantity = document.getElementById("quantity").value;
            const price = document.getElementById("price").value;
            const address = document.getElementById("address").value;
            const image = document.getElementById("cropImage").files[0];
            if (!type || !quantity || !price || !address || !image) {
              Swal.showValidationMessage("Please fill all fields and select an image.");
              return false;
            }
            return { type, quantity, price, address, image };
          },
        }).then((formData) => {
          if (formData.isConfirmed) {
            const data = formData.value;
            const reader = new FileReader();
            reader.onload = function (e) {
              const imgSrc = e.target.result;
              const newCard = document.createElement("div");
              newCard.className = "crop-card";
              newCard.innerHTML = `
                <img src="${imgSrc}" alt="Crop" />
                <h3>${data.type}</h3>
                <p><strong>Quantity:</strong> ${data.quantity} kg</p>
                <p><strong>Price:</strong> ₹${data.price}</p>
                <p><strong>Address:</strong> ${data.address}</p>
              `;
              document.getElementById("uploadedCrops").appendChild(newCard);
              VanillaTilt.init(newCard, {
                max: 15,
                speed: 400,
                glare: true,
                "max-glare": 0.5,
              });
            };
            reader.readAsDataURL(data.image);
          }
        });
      }
    });
  });
  