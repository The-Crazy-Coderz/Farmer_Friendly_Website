const marketProducts = [
    { id: 'm1', name: 'Tomatoes', price: '₹30/kg', description: 'Fresh, juicy, and organic tomatoes from the farm.' },
    { id: 'm2', name: 'Potatoes', price: '₹25/kg', description: 'Farm-fresh potatoes with great taste.' },
    { id: 'm3', name: 'Onions', price: '₹20/kg', description: 'Crisp, flavorful onions ideal for cooking.' },
    { id: 'm4', name: 'Spinach', price: '₹15/bunch', description: 'Fresh, healthy, and nutritious spinach.' }
  ];
  
  function displayMarketProducts() {
    const container = document.getElementById('marketList');
    container.innerHTML = '';
  
    marketProducts.forEach(product => {
      const card = document.createElement('div');
      card.className = 'market-card';
  
      card.innerHTML = `
        <h4>${product.name}</h4>
        <p>${product.description}</p>
        <p class="price">${product.price}</p>
      `;
  
      container.appendChild(card);
    });
  }
  
  function filterMarketProducts() {
    const query = document.getElementById('searchMarket').value.toLowerCase();
    const cards = document.querySelectorAll('.market-card');
    cards.forEach(card => {
      const name = card.querySelector('h4').textContent.toLowerCase();
      card.style.display = name.includes(query) ? 'block' : 'none';
    });
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    displayMarketProducts();
    document.getElementById('searchMarket').addEventListener('input', filterMarketProducts);
  });
  