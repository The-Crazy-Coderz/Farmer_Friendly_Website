document.getElementById("farmerProfileForm").addEventListener("submit", async (e) => {
    e.preventDefault();
  
    const body = {
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      address: document.getElementById("address").value,
      crops: document.getElementById("crops").value,
      landSize: document.getElementById("landSize").value,
    };
  
    const res = await fetch("http://localhost:5000/api/farmer/update-profile", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
      body: JSON.stringify(body),
    });
  
    const data = await res.json();
    alert(data.success ? "✅ Profile updated!" : "❌ Update failed");
  });
  
  async function loadTransactions() {
    const res = await fetch("http://localhost:5000/api/farmer/transactions", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
  
    const data = await res.json();
    const ul = document.getElementById("farmerTransactions");
  
    if (data.transactions && data.transactions.length > 0) {
      data.transactions.forEach((txn) => {
        const li = document.createElement("li");
        li.innerHTML = `🧺 <strong>${txn.cropName}</strong> — ${txn.quantity}kg sold for ₹${txn.amount} on ${new Date(txn.date).toLocaleDateString()}`;
        ul.appendChild(li);
      });
    } else {
      ul.innerHTML = "<li>No transactions found yet.</li>";
    }
  }
  loadTransactions();
  