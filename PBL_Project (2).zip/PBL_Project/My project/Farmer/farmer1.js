// farmer1.js

function navigateTo(page) {
  // Navigate to the given page (e.g., crops.html)
  window.location.href = page;
}
