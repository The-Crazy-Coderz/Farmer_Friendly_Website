document.getElementById("consumerProfileForm").addEventListener("submit", async function (e) {
    e.preventDefault();
  
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const location = document.getElementById("location").value;
    const phone = document.getElementById("phone").value;
  
    const response = await fetch("http://localhost:5000/api/consumer/update-profile", {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + localStorage.getItem("token")
      },
      body: JSON.stringify({ name, email, location, phone })
    });
  
    const data = await response.json();
    if (data.success) {
      alert("Profile updated successfully!");
      location.reload();
    } else {
      alert("Update failed: " + data.msg);
    }
  });
  
  // Optional: Fetch past orders
  (async function loadTransactions() {
    const res = await fetch("http://localhost:5000/api/consumer/transactions", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token")
      }
    });
    const result = await res.json();
    const list = document.getElementById("orderHistory");
    list.innerHTML = result.transactions.map(t => `<li>${t.item} - ₹${t.amount}</li>`).join('');
  })();
  