function showForm(type) {
  document.getElementById('formSelection').classList.add('hidden');
  document.getElementById('loginForm').classList.add('hidden');
  document.getElementById('registerForm').classList.add('hidden');
  document.getElementById('forgotPasswordForm').classList.add('hidden');
  document.getElementById(type + 'Form').classList.remove('hidden');
}

function goBack() {
  document.getElementById('formSelection').classList.remove('hidden');
  document.getElementById('loginForm').classList.add('hidden');
  document.getElementById('registerForm').classList.add('hidden');
  document.getElementById('forgotPasswordForm').classList.add('hidden');
}

function showForgotPassword() {
  document.getElementById('loginForm').classList.add('hidden');
  document.getElementById('forgotPasswordForm').classList.remove('hidden');
}

function goBackToLogin() {
  document.getElementById('forgotPasswordForm').classList.add('hidden');
  document.getElementById('loginForm').classList.remove('hidden');
}

document.getElementById('userTypeRegister').addEventListener('change', function () {
  const userType = this.value;
  document.getElementById('farmerFields').classList.add('hidden');
  document.getElementById('consumerFields').classList.add('hidden');
  document.getElementById('industryFields').classList.add('hidden');
  if (userType === 'farmer') {
    document.getElementById('farmerFields').classList.remove('hidden');
  } else if (userType === 'consumer') {
    document.getElementById('consumerFields').classList.remove('hidden');
  } else if (userType === 'industry') {
    document.getElementById('industryFields').classList.remove('hidden');
  }
});

function validateLogin(e) {
  e.preventDefault();
  alert("Login functionality will be connected to the backend.");
}

function validateRegister(e) {
  e.preventDefault();
  alert("Registration functionality will be connected to the backend.");
}

function resetPassword(e) {
  e.preventDefault();
  alert("Password reset functionality will be connected to the backend.");
}
