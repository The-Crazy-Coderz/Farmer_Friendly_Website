// consumer.js

function handleClick(sectionName) {
    const popup = document.createElement("div");
    popup.textContent = `✨ You clicked on ${sectionName}!`;
    popup.style.position = "fixed";
    popup.style.top = "50px";
    popup.style.right = "50px";
    popup.style.padding = "15px 25px";
    popup.style.background = "rgba(0, 123, 255, 0.9)";
    popup.style.color = "#fff";
    popup.style.fontWeight = "bold";
    popup.style.borderRadius = "10px";
    popup.style.boxShadow = "0 5px 25px rgba(0,0,0,0.3)";
    popup.style.zIndex = 9999;
    popup.style.opacity = 0;
    popup.style.transition = "opacity 0.5s ease";
  
    document.body.appendChild(popup);
  
    setTimeout(() => {
      popup.style.opacity = 1;
    }, 100);
  
    setTimeout(() => {
      popup.style.opacity = 0;
      setTimeout(() => popup.remove(), 500);
    }, 2000);
  }
  
  