const products = [
    { id: 'p1', name: 'Tomatoes', price: '₹30/kg', description: 'Fresh and juicy red tomatoes.' },
    { id: 'p2', name: 'Potatoes', price: '₹25/kg', description: 'Organic farm-grown potatoes.' },
    { id: 'p3', name: 'Onions', price: '₹20/kg', description: 'Crisp and flavorful onions.' },
    { id: 'p4', name: 'Spinach', price: '₹15/bunch', description: 'Leafy and fresh spinach.' }
  ];
  
  function displayProducts() {
    const container = document.getElementById('productList');
    container.innerHTML = '';
  
    products.forEach(product => {
      const card = document.createElement('div');
      card.className = 'product-card';
  
      card.innerHTML = `
        <h4>${product.name}</h4>
        <p>${product.description}</p>
        <p><strong>${product.price}</strong></p>
        <button onclick="addToCart('${product.id}')">Add to Cart</button>
      `;
  
      container.appendChild(card);
    });
  }
  
  function addToCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const product = products.find(p => p.id === productId);
    if (product) {
      cart.push(product);
      localStorage.setItem('cart', JSON.stringify(cart));
      alert(`${product.name} added to cart!`);
    }
  }
  
  function filterProducts() {
    const query = document.getElementById('searchProduct').value.toLowerCase();
    const cards = document.querySelectorAll('.product-card');
    cards.forEach(card => {
      const name = card.querySelector('h4').textContent.toLowerCase();
      card.style.display = name.includes(query) ? 'block' : 'none';
    });
  }
  
  document.addEventListener('DOMContentLoaded', () => {
    displayProducts();
    document.getElementById('searchProduct').addEventListener('input', filterProducts);
  });
  