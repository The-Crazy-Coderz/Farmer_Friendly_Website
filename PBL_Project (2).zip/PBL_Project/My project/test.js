const products = [
  { name: "Organic Booster", offer: "20% OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657920.png" },
  { name: "GrowFast+ B", offer: "Buy 1 Get 1", img: "https://cdn-icons-png.flaticon.com/512/7657/7657918.png" },
  { name: "PowerNPK 50", offer: "Flat ₹50 OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657925.png" },
  { name: "SoilPro Green", offer: "10% Cashback", img: "https://cdn-icons-png.flaticon.com/512/7657/7657923.png" },
  { name: "MagicRoot Boost", offer: "Free Delivery", img: "https://cdn-icons-png.flaticon.com/512/7657/7657930.png" },
  { name: "NitroGrow XL", offer: "Combo Offer", img: "https://cdn-icons-png.flaticon.com/512/7657/7657933.png" },
  { name: "K-Micro Plus", offer: "New Arrival", img: "https://cdn-icons-png.flaticon.com/512/7657/7657922.png" },
  { name: "BioBloom Advance", offer: "25% OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657932.png" },
  { name: "AgroZyme Spray", offer: "₹100 OFF", img: "https://cdn-icons-png.flaticon.com/512/7657/7657931.png" },
  { name: "GreenEdge Pro", offer: "5% Discount", img: "https://cdn-icons-png.flaticon.com/512/7657/7657924.png" }
];

let cart = [];
let wishlist = [];

function showSection(id) {
  document.querySelectorAll('section').forEach(sec => sec.classList.remove('visible'));
  document.getElementById(id).classList.add('visible');
}

function isInCart(name) {
  return cart.some(p => p.name === name);
}

function isInWishlist(name) {
  return wishlist.some(p => p.name === name);
}

function renderList(containerId, items, context) {
  const container = document.getElementById(containerId);
  const template = document.getElementById('product-card-template');
  container.innerHTML = '';

  items.forEach(product => {
    const clone = template.content.cloneNode(true);
    const card = clone.querySelector('.product-card');
    const img = clone.querySelector('img');
    const title = clone.querySelector('h3');
    const offer = clone.querySelector('p');
    const addCartBtn = clone.querySelector('.add-cart');
    const addWishlistBtn = clone.querySelector('.add-wishlist');
    const buyNowBtn = clone.querySelector('.buy-now');

    img.src = product.img;
    img.alt = product.name;
    title.textContent = product.name;
    offer.textContent = product.offer;

    if (context === "main") {
      if (isInCart(product.name)) {
        addCartBtn.textContent = "Added to Cart";
        addCartBtn.classList.add("added");
        addCartBtn.onclick = () => showSection('cart');
      } else {
        addCartBtn.textContent = "Add to Cart";
        addCartBtn.onclick = () => handleCartClick(product);
      }

      if (isInWishlist(product.name)) {
        addWishlistBtn.textContent = "Added to Wishlist";
        addWishlistBtn.classList.add("added");
        addWishlistBtn.onclick = () => showSection('wishlist');
      } else {
        addWishlistBtn.textContent = "Add to Wishlist";
        addWishlistBtn.onclick = () => handleWishlistClick(product);
      }

      buyNowBtn.onclick = () => buyNow(product);
    }

    if (context === "cart") {
      addCartBtn.remove();
      addWishlistBtn.remove();
      buyNowBtn.onclick = () => buyNow(product);

      const removeBtn = document.createElement('button');
      removeBtn.textContent = "Remove from Cart";
      removeBtn.onclick = () => removeFromCart(product.name);
      card.appendChild(removeBtn);
    }

    if (context === "wishlist") {
      addCartBtn.remove();
      addWishlistBtn.remove();
      buyNowBtn.onclick = () => buyNow(product);

      const removeBtn = document.createElement('button');
      removeBtn.textContent = "Remove from Wishlist";
      removeBtn.onclick = () => removeFromWishlist(product.name);
      card.appendChild(removeBtn);
    }

    container.appendChild(clone);
  });
}

function handleCartClick(product) {
  if (!isInCart(product.name)) {
    if (cart.length >= 25) return alert("Cart is full (25 items max)");
    cart.push(product);
    renderAll();
  }
}

function handleWishlistClick(product) {
  if (!isInWishlist(product.name)) {
    if (wishlist.length >= 25) return alert("Wishlist is full (25 items max)");
    wishlist.push(product);
    renderAll();
  }
}

function removeFromCart(name) {
  cart = cart.filter(p => p.name !== name);
  renderAll();
}

function removeFromWishlist(name) {
  wishlist = wishlist.filter(p => p.name !== name);
  renderAll();
}

function buyNow(product) {
  alert(`Order placed for "${product.name}"`);
}

function renderAll() {
  renderList('product-list', products, 'main');
  renderList('cart-items', cart, 'cart');
  renderList('wishlist-items', wishlist, 'wishlist');
}

renderAll();





