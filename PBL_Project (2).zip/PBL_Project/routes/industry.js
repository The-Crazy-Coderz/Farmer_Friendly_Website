/*const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Industry = require("../models/Industry");

const router = express.Router();

// Register Industry
router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const existingIndustry = await Industry.findOne({ email });

        if (existingIndustry) {
            return res.status(400).json({ message: "Industry already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newIndustry = new Industry({ name, email, password: hashedPassword });

        await newIndustry.save();
        res.status(201).json({ message: "Industry registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering industry", error });
    }
});

// Login Industry
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;
        const industry = await Industry.findOne({ email });

        if (!industry) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const isMatch = await bcrypt.compare(password, industry.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign({ industryId: industry._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error });
    }
});

module.exports = router;
*/
/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Industry = require("../models/Industry");
const auth = require("../middlewares/authMiddleware");

const router = express.Router();

// Public Routes
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const existingIndustry = await Industry.findOne({ email });

    if (existingIndustry) {
      return res.status(400).json({ message: "Industry already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newIndustry = new Industry({ name, email, password: hashedPassword });

    await newIndustry.save();
    res.status(201).json({ message: "Industry registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error registering industry", error });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const industry = await Industry.findOne({ email });

    if (!industry) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, industry.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ industryId: industry._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
  } catch (error) {
    res.status(500).json({ message: "Error logging in", error });
  }
});

// Protected Route
router.get("/profile", auth, async (req, res) => {
  try {
    const industry = await Industry.findById(req.user.industryId);
    res.json(industry);
  } catch (error) {
    res.status(500).json({ message: "Error fetching industry data" });
  }
});

module.exports = router;
*/


const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Industry = require(path.join(__dirname, '..', 'models', 'Industry'));
const { sendOtpToEmail, verifyOtp } = require(path.join(__dirname, '..', 'middleware', 'mailer'));
const verifyToken = require('../middleware/verifytoken');

const router = express.Router();
let pendingIndustries = {};

// ✅ Send OTP
router.post("/send-email-otp", async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
        return res.status(400).json({ message: "All fields are required" });

    const existing = await Industry.findOne({ email });
    if (existing)
        return res.status(400).json({ message: "Email already registered" });

    const result = await sendOtpToEmail(email);
    if (result.success) {
        pendingIndustries[email] = { name, email, password };
        return res.json({ message: "OTP sent to Gmail" });
    }
    return res.status(500).json({ message: "Failed to send OTP", error: result.error });
});

// ✅ Verify OTP & Register
router.post("/verify-email-otp", async (req, res) => {
    const { email, otp } = req.body;
    if (!email || !otp || !pendingIndustries[email])
        return res.status(400).json({ message: "Invalid email or OTP" });

    if (!verifyOtp(email, otp))
        return res.status(400).json({ message: "Invalid or expired OTP" });

    const { name, password } = pendingIndustries[email];
    delete pendingIndustries[email];

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newIndustry = new Industry({ name, email, password: hashedPassword });
        await newIndustry.save();

        const token = jwt.sign({ industryId: newIndustry._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(201).json({ message: "Industry registered", token });
    } catch (error) {
        return res.status(500).json({ message: "Error registering industry", error: error.message });
    }
});

// ✅ Login
router.post("/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password)
        return res.status(400).json({ message: "All fields are required" });

    const industry = await Industry.findOne({ email });
    if (!industry || !(await bcrypt.compare(password, industry.password)))
        return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ industryId: industry._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    return res.status(200).json({ message: "Login successful", token });
});

// ✅ Update Profile
router.put("/update-profile", verifyToken, async (req, res) => {
    try {
        const industryId = req.user.industryId;
        const { name, email, address } = req.body;

        const updated = await Industry.findByIdAndUpdate(industryId, { name, email, address }, { new: true });
        if (!updated)
            return res.status(404).json({ message: "Industry not found" });

        res.json({ message: "Profile updated", industry: updated });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
});

module.exports = router;
