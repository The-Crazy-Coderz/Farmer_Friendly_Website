/*const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Consumer = require("../models/Consumer"); // MongoDB model for Consumer
const Industry = require("../models/Industry"); // MongoDB model for Industry
const mysql = require("mysql2/promise");

const router = express.Router();
const secretKey = process.env.JWT_SECRET;

// MySQL Connection for Farmers
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE,
});

// **Register Consumer (MongoDB)**
router.post("/register-consumer", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if the email already exists
    const existingConsumer = await Consumer.findOne({ email });
    if (existingConsumer) {
      return res.status(400).json({ error: "Consumer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const consumer = new Consumer({ name, email, password: hashedPassword });
    await consumer.save();

    res.status(201).json({ message: "Consumer registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error registering consumer" });
  }
});

// **Register Farmer (MySQL)**
router.post("/register-farmer", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if the email already exists
    const [existingFarmer] = await pool.execute("SELECT * FROM farmers WHERE email = ?", [email]);
    if (existingFarmer.length > 0) {
      return res.status(400).json({ error: "Farmer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const [rows] = await pool.execute(
      "INSERT INTO farmers (name, email, password) VALUES (?, ?, ?)",
      [name, email, hashedPassword]
    );

    res.status(201).json({ message: "Farmer registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error registering farmer" });
  }
});

// **Register Industry (MongoDB)**
router.post("/register-industry", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if the email already exists
    const existingIndustry = await Industry.findOne({ email });
    if (existingIndustry) {
      return res.status(400).json({ error: "Industry already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const industry = new Industry({ name, email, password: hashedPassword });
    await industry.save();

    res.status(201).json({ message: "Industry registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error registering industry" });
  }
});

// **Login Route (Consumers, Farmers & Industries)**
router.post("/login", async (req, res) => {
  const { email, password, userType } = req.body; // userType = 'consumer', 'farmer', or 'industry'

  try {
    let user;
    if (userType === "consumer") {
      // For Consumer (MongoDB)
      user = await Consumer.findOne({ email });
    } else if (userType === "farmer") {
      // For Farmer (MySQL)
      const [rows] = await pool.execute("SELECT * FROM farmers WHERE email = ?", [email]);
      user = rows[0];
    } else if (userType === "industry") {
      // For Industry (MongoDB)
      user = await Industry.findOne({ email });
    }

    if (!user) return res.status(400).json({ error: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

    // Generate JWT token with user info and userType
    const token = jwt.sign({ id: user.id, email: user.email, userType }, secretKey, { expiresIn: "1h" });

    res.json({ token, userType });
  } catch (error) {
    res.status(500).json({ error: "Login error" });
  }
});

module.exports = router;
*/

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Consumer = require("../models/Consumer");
const Industry = require("../models/Industry");
const mysql = require("mysql2/promise");
const { sendOtpToEmail, verifyOtp } = require("../middlewares/mailer");

const router = express.Router();
const secretKey = process.env.JWT_SECRET;

// MySQL Connection for Farmers
const pool = mysql.createPool({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USER,
  password: process.env.MYSQL_PASSWORD,
  database: process.env.MYSQL_DATABASE,
});

// ✅ Send OTP Endpoint
router.post("/send-otp", async (req, res) => {
  const { email } = req.body;
  if (!email) return res.status(400).json({ error: "Email is required" });

  const result = await sendOtpToEmail(email);
  if (result.success) {
    return res.status(200).json({ message: "OTP sent successfully" });
  } else {
    return res.status(500).json({ error: result.error || "Failed to send OTP" });
  }
});

// ✅ Verify OTP Endpoint
router.post("/verify-otp", (req, res) => {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ error: "Email and OTP are required" });

  const isValid = verifyOtp(email, otp);
  if (isValid) {
    return res.status(200).json({ message: "OTP verified successfully" });
  } else {
    return res.status(400).json({ error: "Invalid or expired OTP" });
  }
});

// **Register Consumer (MongoDB)**
router.post("/register-consumer", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const existingConsumer = await Consumer.findOne({ email });
    if (existingConsumer) {
      return res.status(400).json({ error: "Consumer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const consumer = new Consumer({ name, email, password: hashedPassword });
    await consumer.save();

    res.status(201).json({ message: "Consumer registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error registering consumer" });
  }
});

// **Register Farmer (MySQL)**
router.post("/register-farmer", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const [existingFarmer] = await pool.execute("SELECT * FROM farmers WHERE email = ?", [email]);
    if (existingFarmer.length > 0) {
      return res.status(400).json({ error: "Farmer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const [rows] = await pool.execute(
      "INSERT INTO farmers (name, email, password) VALUES (?, ?, ?)",
      [name, email, hashedPassword]
    );

    res.status(201).json({ message: "Farmer registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error registering farmer" });
  }
});

// **Register Industry (MongoDB)**
router.post("/register-industry", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const existingIndustry = await Industry.findOne({ email });
    if (existingIndustry) {
      return res.status(400).json({ error: "Industry already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const industry = new Industry({ name, email, password: hashedPassword });
    await industry.save();

    res.status(201).json({ message: "Industry registered successfully" });
  } catch (error) {
    res.status(500).json({ error: "Error registering industry" });
  }
});

// **Login Route (Consumers, Farmers & Industries)**
router.post("/login", async (req, res) => {
  const { email, password, userType } = req.body;

  try {
    let user;
    if (userType === "consumer") {
      user = await Consumer.findOne({ email });
    } else if (userType === "farmer") {
      const [rows] = await pool.execute("SELECT * FROM farmers WHERE email = ?", [email]);
      user = rows[0];
    } else if (userType === "industry") {
      user = await Industry.findOne({ email });
    }

    if (!user) return res.status(400).json({ error: "User not found" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: "Invalid credentials" });

    const token = jwt.sign({ id: user.id, email: user.email, userType }, secretKey, { expiresIn: "1h" });

    res.json({ token, userType });
  } catch (error) {
    res.status(500).json({ error: "Login error" });
  }
});

module.exports = router;
