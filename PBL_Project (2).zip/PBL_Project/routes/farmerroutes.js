/*const express = require("express");
const Farmer = require("../models/Farmer");
const jwt = require("jsonwebtoken");
const router = express.Router();
require("dotenv").config();

// Register Farmer
router.post("/register/farmer", async (req, res) => {
  try {
    const { farmer_id, name, email, password } = req.body;

    // Check if farmer already exists
    let existingFarmer = await Farmer.findOne({ email });
    if (existingFarmer) return res.status(400).json({ message: "Email already exists" });

    // Create new farmer
    const newFarmer = new Farmer({ farmer_id, name, email, password });
    await newFarmer.save();

    res.status(201).json({ message: "Farmer registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

module.exports = router;
*/
/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Farmer = require("../models/Farmer");

const router = express.Router();

// ✅ Register Farmer (Path: /api/farmer/register)
router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const existingFarmer = await Farmer.findOne({ email });
        if (existingFarmer) {
            return res.status(400).json({ message: "Farmer already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newFarmer = new Farmer({ name, email, password: hashedPassword });

        await newFarmer.save();
        res.status(201).json({ message: "Farmer registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering farmer", error: error.message });
    }
});

// ✅ Login Farmer (Path: /api/farmer/login)
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const farmer = await Farmer.findOne({ email });
        if (!farmer) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const isMatch = await bcrypt.compare(password, farmer.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error: error.message });
    }
});

module.exports = router;
*/
/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Farmer = require("../models/Farmer");
const auth = require("../middlewares/authMiddleware");

const router = express.Router();

// Public Routes
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const existingFarmer = await Farmer.findOne({ email });
    if (existingFarmer) {
      return res.status(400).json({ message: "Farmer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newFarmer = new Farmer({ name, email, password: hashedPassword });

    await newFarmer.save();
    res.status(201).json({ message: "Farmer registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error registering farmer", error: error.message });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const farmer = await Farmer.findOne({ email });
    if (!farmer) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, farmer.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
  } catch (error) {
    res.status(500).json({ message: "Error logging in", error: error.message });
  }
});

// Protected Route
router.get("/profile", auth, async (req, res) => {
  try {
    const farmer = await Farmer.findById(req.user.farmerId);
    res.json(farmer);
  } catch (error) {
    res.status(500).json({ message: "Error fetching farmer data" });
  }
});

module.exports = router;
*/

/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path=require("path");
const Farmer = require(path.join(__dirname, '..', 'models', 'Farmer'));

const router = express.Router();

// ✅ Register Farmer (Path: /api/farmer/register)
router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;
        if (!name || !email || !password) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const existingFarmer = await Farmer.findOne({ email });
        if (existingFarmer) {
            return res.status(400).json({ message: "Farmer already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newFarmer = new Farmer({ name, email, password: hashedPassword });

        await newFarmer.save();
        res.status(201).json({ message: "Farmer registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering farmer", error: error.message });
    }
});

// ✅ Login Farmer (Path: /api/farmer/login)
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;
        if (!email || !password) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const farmer = await Farmer.findOne({ email });
        if (!farmer) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const isMatch = await bcrypt.compare(password, farmer.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error: error.message });
    }
});

module.exports = router;

*/
/*

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Farmer = require(path.join(__dirname, '..', 'models', 'Farmer'));
const { sendOtpToEmail, verifyOtp } = require("../middleware/mailer"); // ✅ Modular OTP helper
const verifyToken = require('../middleware/verifytoken');

const router = express.Router();
let pendingFarmers = {}; // Temporarily store unverified farmers

//update Profile
router.put("/update-profile", verifyToken, async (req, res) => {
    try {
      const farmerId = req.user.farmerId; // from JWT
      const { name, email, address } = req.body;
  
      const updated = await Farmer.findByIdAndUpdate(
        farmerId,
        { name, email, address },
        { new: true }
      );
  
      if (!updated) return res.status(404).json({ success: false, msg: "Farmer not found" });
  
      res.json({ success: true, farmer: updated });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, msg: "Server error" });
    }
  });
// ✅ 1. Send OTP to Gmail (Path: /api/farmer/send-email-otp)
router.post("/send-email-otp", async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const existing = await Farmer.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const result = await sendOtpToEmail(email);
    if (result.success) {
        pendingFarmers[email] = { name, email, password };
        return res.status(200).json({ message: "OTP sent to Gmail" });
    } else {
        return res.status(500).json({ message: "Failed to send OTP", error: result.error });
    }
});

// ✅ 2. Verify OTP & Register Farmer (Path: /api/farmer/verify-email-otp)
router.post("/verify-email-otp", async (req, res) => {
    const { email, otp } = req.body;

    if (!email || !otp || !pendingFarmers[email]) {
        return res.status(400).json({ message: "Invalid email or OTP" });
    }

    if (!verifyOtp(email, otp)) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    const { name, password } = pendingFarmers[email];
    delete pendingFarmers[email];

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newFarmer = new Farmer({ name, email, password: hashedPassword });
        await newFarmer.save();

        const token = jwt.sign({ farmerId: newFarmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(201).json({
            message: "Farmer registered successfully",
            token,
            redirectTo: "/test.html"
        });
    } catch (error) {
        return res.status(500).json({ message: "Error registering farmer", error: error.message });
    }
});

// ✅ 3. Login Farmer (Path: /api/farmer/login)
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const farmer = await Farmer.findOne({ email });
    if (!farmer) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, farmer.password);
    if (!isMatch) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    return res.status(200).json({
        message: "Login successful",
        token,
        redirectTo: "/test.html"
    });
});

module.exports = router;
*/




/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Farmer = require(path.join(__dirname, '..', 'models', 'Farmer'));
const { sendOtpToEmail, verifyOtp } = require("../middleware/mailer"); // ✅ Modular OTP helper
const verifyToken = require('../middleware/verifytoken');

const router = express.Router();
let pendingFarmers = {}; // Temporarily store unverified farmers

//update Profile
router.put("/update-profile", verifyToken, async (req, res) => {
    try {
      const farmerId = req.user.farmerId; // from JWT
      const { name, email, address } = req.body;
  
      const updated = await Farmer.findByIdAndUpdate(
        farmerId,
        { name, email, address },
        { new: true }
      );
  
      if (!updated) return res.status(404).json({ success: false, msg: "Farmer not found" });
  
      res.json({ success: true, farmer: updated });
    } catch (err) {
      console.error(err);
      res.status(500).json({ success: false, msg: "Server error" });
    }
  });
// ✅ 1. Send OTP to Gmail (Path: /api/farmer/send-email-otp)
router.post("/send-email-otp", async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const existing = await Farmer.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const result = await sendOtpToEmail(email);
    if (result.success) {
        pendingFarmers[email] = { name, email, password };
        return res.status(200).json({ message: "OTP sent to Gmail" });
    } else {
        return res.status(500).json({ message: "Failed to send OTP", error: result.error });
    }
});

// ✅ 2. Verify OTP & Register Farmer (Path: /api/farmer/verify-email-otp)
router.post("/verify-email-otp", async (req, res) => {
    const { email, otp } = req.body;

    if (!email || !otp || !pendingFarmers[email]) {
        return res.status(400).json({ message: "Invalid email or OTP" });
    }

    if (!verifyOtp(email, otp)) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    const { name, password } = pendingFarmers[email];
    delete pendingFarmers[email];

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newFarmer = new Farmer({ name, email, password: hashedPassword });
        await newFarmer.save();

        const token = jwt.sign({ farmerId: newFarmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(201).json({
            message: "Farmer registered successfully",
            token,
            redirectTo: "/test.html"
        });
    } catch (error) {
        return res.status(500).json({ message: "Error registering farmer", error: error.message });
    }
});

// ✅ 3. Login Farmer (Path: /api/farmer/login)
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const farmer = await Farmer.findOne({ email });
    if (!farmer) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, farmer.password);
    if (!isMatch) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    return res.status(200).json({
        message: "Login successful",
        token,
        redirectTo: "/test.html"
    });
});

module.exports = router;
*/
/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Farmer = require(path.join(__dirname, '..', 'models', 'Farmer'));
const { sendOtpToEmail, verifyOtp } = require("../middleware/mailer"); // OTP helpers
const verifyToken = require('../middleware/verifytoken');

const router = express.Router();
let pendingFarmers = {}; // Store unverified farmer data temporarily

// ✅ 1. Send OTP to Gmail for registration
router.post("/send-email-otp", async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const existing = await Farmer.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const result = await sendOtpToEmail(email); // Sends OTP + stores it in memory
    if (result.success) {
        pendingFarmers[email] = { name, email, password };
        return res.status(200).json({ message: "OTP sent to Gmail" });
    } else {
        return res.status(500).json({ message: "Failed to send OTP", error: result.error });
    }
});

// ✅ 2. Verify OTP and Register Farmer
router.post("/verify-email-otp", async (req, res) => {
    const { email, otp } = req.body;

    if (!email || !otp || !pendingFarmers[email]) {
        return res.status(400).json({ message: "Invalid email or OTP" });
    }

    if (!verifyOtp(email, otp)) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    const { name, password } = pendingFarmers[email];
    delete pendingFarmers[email]; // Remove after verification

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newFarmer = new Farmer({ name, email, password: hashedPassword });
        await newFarmer.save();

        const token = jwt.sign({ farmerId: newFarmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(201).json({
            message: "Farmer registered successfully",
            token,
            redirectTo: "/test.html"
        });
    } catch (error) {
        return res.status(500).json({ message: "Error registering farmer", error: error.message });
    }
});

// ✅ 3. Login Farmer
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const farmer = await Farmer.findOne({ email });
    if (!farmer) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, farmer.password);
    if (!isMatch) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    return res.status(200).json({
        message: "Login successful",
        token,
        redirectTo: "/test.html"
    });
});

// ✅ 4. Update Farmer Profile
router.put("/update-profile", verifyToken, async (req, res) => {
    try {
        const farmerId = req.user.farmerId; // from JWT token
        const { name, email, address } = req.body;

        const updated = await Farmer.findByIdAndUpdate(
            farmerId,
            { name, email, address },
            { new: true }
        );

        if (!updated) return res.status(404).json({ success: false, msg: "Farmer not found" });

        res.json({ success: true, farmer: updated });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, msg: "Server error" });
    }
});

module.exports = router;
*/



/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Farmer = require(path.join(__dirname, '..', 'models', 'Farmer'));
const { sendOtpToEmail, verifyOtp } = require("../middleware/mailer"); // OTP helpers
const verifyToken = require('../middleware/verifytoken'); // Token verification middleware
//const otpStore = require('../farmer-Backend/utils/otpStore');


const router = express.Router();
let pendingFarmers = {}; // Store unverified farmer data temporarily

// ✅ 1. Send OTP to Gmail for registration
router.post("/send-email-otp", async (req, res) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const existing = await Farmer.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const result = await sendOtpToEmail(email); // Sends OTP + stores it in memory
    if (result.success) {
        pendingFarmers[email] = { name, email, password };
        return res.status(200).json({ message: "OTP sent to Gmail" });
    } else {
        return res.status(500).json({ message: "Failed to send OTP", error: result.error });
    }
});

// ✅ 2. Verify OTP and Register Farmer
router.post("/verify-email-otp", async (req, res) => { // Keep path as "/verify-email-otp"
    const { email, otp } = req.body;

    if (!email || !otp || !pendingFarmers[email]) {
        return res.status(400).json({ message: "Invalid email or OTP" });
    }

    if (!verifyOtp(email, otp)) {
        return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    const { name, password } = pendingFarmers[email];
    delete pendingFarmers[email]; // Remove after verification

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newFarmer = new Farmer({ name, email, password: hashedPassword });
        await newFarmer.save();

        const token = jwt.sign({ farmerId: newFarmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(201).json({
            message: "Farmer registered successfully",
            token,
            redirectTo: "/test.html"
        });
    } catch (error) {
        return res.status(500).json({ message: "Error registering farmer", error: error.message });
    }
});

// ✅ 3. Login Farmer
router.post("/login", async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: "All fields are required" });
    }

    const farmer = await Farmer.findOne({ email });
    if (!farmer) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, farmer.password);
    if (!isMatch) {
        return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    return res.status(200).json({
        message: "Login successful",
        token,
        redirectTo: "/test.html"
    });
});

// ✅ 4. Update Farmer Profile
router.put("/update-profile", verifyToken, async (req, res) => {
    try {
        const farmerId = req.user.farmerId; // from JWT token
        const { name, email, address } = req.body;

        const updated = await Farmer.findByIdAndUpdate(
            farmerId,
            { name, email, address },
            { new: true }
        );

        if (!updated) return res.status(404).json({ success: false, msg: "Farmer not found" });

        res.json({ success: true, farmer: updated });
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, msg: "Server error" });
    }
});

module.exports = router;
*/


const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Farmer = require("../models/Farmer");

const router = express.Router();

// ✅ Register Farmer
router.post("/register", async (req, res) => {
  try {
    const {
      name, email, phoneNumber, dob, gender, address, password,
      farmLocation, farmType, farmSize, crops
    } = req.body;

    if (!name || !email || !phoneNumber || !dob || !gender || !address || !password) {
      return res.status(400).json({ message: "Please fill all required fields." });
    }

    const existing = await Farmer.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newFarmer = new Farmer({
      name, email, phoneNumber, dob, gender, address,
      password: hashedPassword,
      farmLocation, farmType, farmSize, crops: crops?.split(",").map(c => c.trim())
    });

    await newFarmer.save();
    res.status(201).json({ message: "Farmer registered successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// ✅ Login Farmer
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const farmer = await Farmer.findOne({ email });

  if (!farmer || !(await bcrypt.compare(password, farmer.password))) {
    return res.status(400).json({ message: "Invalid credentials" });
  }

  const token = jwt.sign({ farmerId: farmer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
  res.status(200).json({ message: "Login successful", token });
});
router.get('/test', (req, res) => {
    res.send('✅ Farmer backend is working!');
  });
module.exports = router;
