const express = require('express');
const router = express.Router();
const Crop = require('../models/cropsmodel');

// Add a new crop
router.post('/upload', async (req, res) => {
  try {
    const newCrop = new Crop(req.body);
    await newCrop.save();
    res.status(201).json({ message: 'Crop uploaded successfully', newCrop });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get crops by farmer ID
router.get('/farmer/:farmerId', async (req, res) => {
  try {
    const crops = await Crop.find({ farmerId: req.params.farmerId });
    res.json(crops);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
