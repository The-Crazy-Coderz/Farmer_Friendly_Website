/*const express = require("express");
const Consumer = require("../models/Consumer");
const jwt = require("jsonwebtoken");
const router = express.Router();
require("dotenv").config();

// Register Consumer
router.post("/register/consumer", async (req, res) => {
  try {
    const { consumer_id, name, email, password } = req.body;

    // Check if consumer already exists
    let existingConsumer = await Consumer.findOne({ email });
    if (existingConsumer) return res.status(400).json({ message: "Email already exists" });

    // Create new consumer
    const newConsumer = new Consumer({ consumer_id, name, email, password });
    await newConsumer.save();

    res.status(201).json({ message: "Consumer registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

module.exports = router;
*/
/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Consumer = require("../models/Consumer.js");

const router = express.Router();

// Register Consumer
router.post("/register", async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const existingConsumer = await Consumer.findOne({ email });

        if (existingConsumer) {
            return res.status(400).json({ message: "Consumer already exists" });
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newConsumer = new Consumer({ name, email, password: hashedPassword });

        await newConsumer.save();
        res.status(201).json({ message: "Consumer registered successfully" });
    } catch (error) {
        res.status(500).json({ message: "Error registering consumer", error });
    }
});

// Login Consumer
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;
        const consumer = await Consumer.findOne({ email });

        if (!consumer) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const isMatch = await bcrypt.compare(password, consumer.password);
        if (!isMatch) {
            return res.status(400).json({ message: "Invalid credentials" });
        }

        const token = jwt.sign({ consumerId: consumer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.json({ message: "Login successful", token });
    } catch (error) {
        res.status(500).json({ message: "Error logging in", error });
    }
});

module.exports = router;
*/
/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Consumer = require("../models/Consumer");
const auth = require("../middlewares/authMiddleware");

const router = express.Router();

// Public Routes
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const existingConsumer = await Consumer.findOne({ email });

    if (existingConsumer) {
      return res.status(400).json({ message: "Consumer already exists" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newConsumer = new Consumer({ name, email, password: hashedPassword });

    await newConsumer.save();
    res.status(201).json({ message: "Consumer registered successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error registering consumer", error });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const consumer = await Consumer.findOne({ email });

    if (!consumer) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const isMatch = await bcrypt.compare(password, consumer.password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign({ consumerId: consumer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    res.json({ message: "Login successful", token });
  } catch (error) {
    res.status(500).json({ message: "Error logging in", error });
  }
});

// Protected Route
router.get("/profile", auth, async (req, res) => {
  try {
    const consumer = await Consumer.findById(req.user.consumerId);
    res.json(consumer);
  } catch (error) {
    res.status(500).json({ message: "Error fetching consumer data" });
  }
});

module.exports = router;
*/

/*
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");
const Consumer = require(path.join(__dirname, '..', 'models', 'Consumer'));
const { sendOtpToEmail, verifyOtp } = require(path.join(__dirname, '..', 'middleware', 'mailer'));
const verifyToken = require('../middleware/verifytoken');

const router = express.Router();
let pendingConsumers = {};

// ✅ Send OTP
router.post("/send-email-otp", async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password)
        return res.status(400).json({ message: "All fields are required" });

    const existing = await Consumer.findOne({ email });
    if (existing)
        return res.status(400).json({ message: "Email already registered" });

    const result = await sendOtpToEmail(email);
    if (result.success) {
        pendingConsumers[email] = { name, email, password };
        return res.json({ message: "OTP sent to Gmail" });
    }
    return res.status(500).json({ message: "Failed to send OTP", error: result.error });
});

// ✅ Verify OTP & Register
router.post("/verify-email-otp", async (req, res) => {
    const { email, otp } = req.body;
    if (!email || !otp || !pendingConsumers[email])
        return res.status(400).json({ message: "Invalid email or OTP" });

    if (!verifyOtp(email, otp))
        return res.status(400).json({ message: "Invalid or expired OTP" });

    const { name, password } = pendingConsumers[email];
    delete pendingConsumers[email];

    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const newConsumer = new Consumer({ name, email, password: hashedPassword });
        await newConsumer.save();

        const token = jwt.sign({ consumerId: newConsumer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        return res.status(201).json({ message: "Consumer registered", token });
    } catch (error) {
        return res.status(500).json({ message: "Error registering consumer", error: error.message });
    }
});

// ✅ Login
router.post("/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password)
        return res.status(400).json({ message: "All fields are required" });

    const consumer = await Consumer.findOne({ email });
    if (!consumer || !(await bcrypt.compare(password, consumer.password)))
        return res.status(400).json({ message: "Invalid credentials" });

    const token = jwt.sign({ consumerId: consumer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
    return res.status(200).json({ message: "Login successful", token });
});

// ✅ Update Profile
router.put("/update-profile", verifyToken, async (req, res) => {
    try {
        const consumerId = req.user.consumerId;
        const { name, email, address } = req.body;

        const updated = await Consumer.findByIdAndUpdate(consumerId, { name, email, address }, { new: true });
        if (!updated)
            return res.status(404).json({ message: "Consumer not found" });

        res.json({ message: "Profile updated", consumer: updated });
    } catch (err) {
        res.status(500).json({ message: "Server error", error: err.message });
    }
});

module.exports = router;
*/

const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Consumer = require("../models/Consumer");

const router = express.Router();

// ✅ Register Consumer
router.post("/register", async (req, res) => {
  try {
    const {
      name, email, phoneNumber, dob, gender, address, password,
      preferredProducts
    } = req.body;

    if (!name || !email || !phoneNumber || !dob || !gender || !address || !password) {
      return res.status(400).json({ message: "Please fill all required fields." });
    }

    const existing = await Consumer.findOne({ email });
    if (existing) return res.status(400).json({ message: "Email already registered" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const newConsumer = new Consumer({
      name, email, phoneNumber, dob, gender, address,
      password: hashedPassword,
      preferredProducts: preferredProducts?.split(",").map(p => p.trim())
    });

    await newConsumer.save();
    res.status(201).json({ message: "Consumer registered successfully" });
  } catch (err) {
    res.status(500).json({ message: "Server error", error: err.message });
  }
});

// ✅ Login Consumer
router.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const consumer = await Consumer.findOne({ email });

  if (!consumer || !(await bcrypt.compare(password, consumer.password))) {
    return res.status(400).json({ message: "Invalid credentials" });
  }

  const token = jwt.sign({ consumerId: consumer._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
  res.status(200).json({ message: "Login successful", token });
});

module.exports = router;
